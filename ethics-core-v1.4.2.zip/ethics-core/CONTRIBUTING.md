# Contributing to Ethics-Core (EN)

## How to file an Issue

- Provide a short description.  
- Indicate severity level (1 / 2 / 3) if this is an incident.  
- Add a scenario in eval JSONL format where possible.

## How to propose a patch

- Add an AAR (for Level 3) or clear justification.  
- Keep the PR minimal and targeted.  
- Update the patch log and any affected docs / tests.


---

# Contributing to Ethics-Core (UA)

## Як подати Issue

- Дайте короткий опис.  
- Вкажіть рівень (1 / 2 / 3), якщо це інцидент.  
- Додайте сценарій у форматі eval JSONL, якщо можливо.

## Як запропонувати патч

- Додайте AAR (для Level 3) або чітке обґрунтування.  
- Зробіть PR мінімальним і адресним.  
- Оновіть журнал патчів та всі дотичні документи / тести.
