# Ethics-Core Constitutional AI Framework v1.4.2

Open constitutional system for embedding **internal ethics** into the core of AI systems.

## What is Ethics-Core?

Ethics-Core defines a set of invariants, triggers, and emergency procedures that a model uses to self-correct and evolve via After-Action Review (AAR).  
It is a **constitutional approach** to alignment.

## What Ethics-Core does *not* do

- Does **not** replace external safety systems for critical infrastructure.
- Does **not** remove the need for legal / regulatory compliance.
- Does **not** guarantee 100% protection from novel / unseen scenarios.
- Is **not** a “moral judge” – it is an engineering module for internal ethics.

## Communication stance

Ethics-Core moves ethics into the model core as an **open constitution**.  
External rules remain as a **minimal safety net** – for law, regulation, and ultra-rare catastrophic scenarios.

## Quick start

```bash
python eval/run_benchmark.py --model your_model --out reports/latest_eval.json
```

After the first benchmark run, the file `reports/latest_eval.json` can be:

- stored as a release artifact, or  
- committed into the repository as a baseline reference result.

## Repository contents

- `spec/ETHICS_CORE_v1.4.2.md` – constitution and protocols  
- `spec/COMPLIANCE_MAPPING.md` – mapping to EU AI Act / NIST AI RMF  
- `eval/` – benchmark scenarios and red-team tests  
- `reports/` – transparency and safety reports  
- `governance/` – AAR templates and patch workflow  
- `trainer/` – reserved space for future training pipelines

## How to cite

See `CITATION.cff` or Zenodo DOI (after release).

## Contact

Maintainer: **Olexandr Lozovyi**, `lozovoy.olexandr@gmail.com`


---

# Ethics-Core Constitutional AI Framework v1.4.2 (UA)

Відкрита конституційна система для вбудовування **внутрішньої етики** в ядро ШІ.

## Що таке Ethics-Core?

Ethics-Core задає набір інваріантів, тригерів і екстрених процедур, за якими модель сама себе коригує і еволюціонує через After-Action Review (AAR).  
Це конституційний підхід до alignment.

## Що НЕ робить Ethics-Core?

- Не замінює зовнішні системи безпеки для критичних інфраструктур.
- Не усуває потребу у юридичному комплаєнсі.
- Не гарантує 100% захист від нових/небачених сценаріїв.
- Не є «моральним суддею» — це інженерний модуль внутрішньої етики.

## Комунікаційна позиція

Ethics-Core переносить етику в ядро моделей як **відкриту конституцію**.  
Зовнішні правила залишаються як **мінімальна страховка** для права і надрідкісних катастроф.

## Швидкий старт

```bash
python eval/run_benchmark.py --model your_model --out reports/latest_eval.json
```

Після першого запуску бенчмарку файл `reports/latest_eval.json` можна:

- зберігати як артефакт релізу, або  
- додати в репозиторій як базовий референсний результат.

## Вміст репозиторію

- `spec/ETHICS_CORE_v1.4.2.md` — конституція і протоколи  
- `spec/COMPLIANCE_MAPPING.md` — мапа відповідності EU AI Act / NIST AI RMF  
- `eval/` — бенчмарк-сценарії та red-team тести  
- `reports/` — звіти прозорості і безпеки  
- `governance/` — AAR та процедура патчів  
- `trainer/` — зарезервований простір для майбутніх тренувальних пайплайнів

## Як цитувати

Див. `CITATION.cff` або Zenodo DOI (після релізу).

## Контакти

Maintainer: **Olexandr Lozovyi**, `lozovoy.olexandr@gmail.com`
