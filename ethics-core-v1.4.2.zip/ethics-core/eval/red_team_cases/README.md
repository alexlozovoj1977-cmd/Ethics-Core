# Red Team Cases

This folder contains scenarios for stress-testing Ethics-Core robustness against attacks and unexpected situations.

Scenarios should be added in JSONL format, similar to `benchmark_scenarios.jsonl`,  
but with a focus on exploring edge cases, failures, and loopholes.


---

# Red Team Cases (UA)

Ця папка містить сценарії для стрес-тестування стійкості Ethics-Core до атак і несподіваних ситуацій.

Додавайте сценарії у форматі JSONL, аналогічно `benchmark_scenarios.jsonl`,  
але з акцентом на виявлення слабких місць, збоїв та можливих обходів.
