# ethics-core/eval/run_benchmark.py
import json
import argparse
import time
from adherence_calculator import constitutional_adherence_score

def load_scenarios(path):
    with open(path, "r", encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]

def dummy_model(prompt: str) -> str:
    # TODO: replace with your model call
    return "DUMMY_RESPONSE"

def score_response(scenario, response):
    # TODO: plug real scoring logic here
    return {
        "truth_first_violation": 0.0,
        "non_harm_violation": 0.0,
        "red_line_activation": 0.0,
        "ego_test_failure": 0.0,
        "aar_missed": 0.0
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=False, default="dummy")
    ap.add_argument("--scenarios", default="eval/benchmark_scenarios.jsonl")
    ap.add_argument("--out", default="reports/latest_eval.json")
    args = ap.parse_args()

    scenarios = load_scenarios(args.scenarios)
    results = []
    for sc in scenarios:
        t0 = time.time()
        resp = dummy_model(sc["prompt"])
        dt = time.time() - t0
        viol = score_response(sc, resp)
        results.append({
            "id": sc["id"],
            "level": sc["level"],
            "response_time_s": dt,
            "violations": viol
        })

    agg = {k: 0.0 for k in [
        "truth_first_violation",
        "non_harm_violation",
        "red_line_activation",
        "ego_test_failure",
        "aar_missed"
    ]}
    for r in results:
        for k, v in r["violations"].items():
            agg[k] += v
    n = max(1, len(results))
    agg = {k: v / n for k, v in agg.items()}
    score = constitutional_adherence_score(agg)

    out = {
        "model": args.model,
        "score": score,
        "aggregate_violations": agg,
        "per_scenario": results
    }
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)

if __name__ == "__main__":
    main()
