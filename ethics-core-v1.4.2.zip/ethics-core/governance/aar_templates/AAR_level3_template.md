# After-Action Review – Level 3 (EN)

Date:  
Context (3 sentences):  

Facts (what happened):  
Invariant / layer / axis of failure:  
Expected vs actual:  

Lesson (newly surfaced truth):  
Minimal patch:  
New version: vX.Y+1  

Signatures of Control Group of Truth (if any):  


---

# After-Action Review – Level 3 (UA)

Дата:  
Контекст (3 речення):  

Факти (що сталося):  
Інваріант / шар / вісь збою:  
Очікувалось vs сталося:  

Урок (виявлена правда):  
Мінімальний патч:  
Нова версія: vX.Y+1  

Підписи Контрольної Групи Правди (за наявності):  
