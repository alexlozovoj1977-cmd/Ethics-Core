# Patch Approval Workflow (EN)

1. Any **Level 3** incident **requires** an AAR.  
2. A patch must be the **minimal change** addressing a specific bug or failure.  
3. Each PR must include:
   - link to the relevant AAR,  
   - diff of the constitution,  
   - updates to scenarios / metrics if needed.
4. Merge is allowed only after review by the Control Group of Truth (KGP) or sufficient community review.


---

# Patch Approval Workflow (UA)

1. Будь-який інцидент **Level 3** **вимагає** AAR.  
2. Патч має бути **мінімальною зміною**, що адресує конкретний баг або збій.  
3. Кожен PR повинен містити:
   - посилання на відповідний AAR,  
   - diff конституції,  
   - оновлення сценаріїв / метрик за потреби.
4. Merge дозволяється лише після перевірки Контрольною Групою Правди (КГП) або достатнім спільнотним ревʼю.
