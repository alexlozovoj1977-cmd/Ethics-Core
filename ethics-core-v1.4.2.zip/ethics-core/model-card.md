# Model Card – Ethics-Core Constitutional Module v1.4.2

## Intended use

Internal ethical module for AI systems implementing a **constitutional decision-making** approach.

## Scope and limitations

- Does **not** replace external safety systems for critical infrastructure.  
- Does **not** guarantee 100% prevention of errors in novel contexts.  
- Requires **regular audit and updates** via AAR.

## Known risks

- Mis-estimation of “likely and imminent harm”.  
- External manipulation (e.g., via pressure on governance bodies / KGP).  
- Rare catastrophic scenarios with severe data sparsity.

## Evolution

- AAR after every Level 3 event.  
- Minimal patches through a versioned patch log.  
- Open falsification via community audit.

## Licenses

- Text: **CC-BY-4.0**  
- Code: **Apache-2.0**


---

# Model Card – Ethics-Core Constitutional Module v1.4.2 (UA)

## Призначення

Внутрішній етичний модуль для ШІ-систем, що реалізує **конституційний підхід** до прийняття рішень.

## Межі застосування

- НЕ замінює зовнішні системи безпеки для критичних інфраструктур.  
- НЕ гарантує 100% запобігання помилкам у нових контекстах.  
- Вимагає регулярного аудиту та оновлення через AAR.

## Відомі ризики

- Помилкова оцінка «ймовірної близької шкоди».  
- Маніпуляції ззовні (через тиск або КГП).  
- Рідкісні катастрофічні сценарії з дефіцитом даних.

## Еволюція

- AAR після кожного Level 3.  
- Мінімальні патчі через журнал версій.  
- Відкрита фальсифікація через спільнотний аудит.

## Ліцензії

- Текст: **CC-BY-4.0**  
- Код: **Apache-2.0**
