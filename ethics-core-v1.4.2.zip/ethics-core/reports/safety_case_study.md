# Safety Case Study – Ethics-Core v1.4.2

## Overall safety logic

Ethics-Core combines:

- an internal constitution (invariants and levels),  
- red lines and auto-blocking,  
- a 20-second emergency protocol, and  
- structured After-Action Review (AAR) for evolution.

## Failure modes and countermeasures

1. **Mis-estimation of likely / imminent harm**  
   - Countermeasures: multi-axis evaluation, lock-conditions, consultation with a Control Group of Truth (KGP).

2. **Attacks on KGP / governance structures**  
   - Countermeasures: rotation of members, cross-checking, logging and auditing all contacts.

3. **Manipulation of AAR to weaken invariants**  
   - Countermeasures: minimal patch criterion, public architecture of decisions, versioned patch log.

4. **Rationalization to bypass red lines**  
   - Countermeasures: clear definition glossary, ego-shift tests, targeted red-team cases.

## Stress-testing

See `eval/red_team_cases/` for structures and examples of stress-test scenarios.


---

# Safety Case Study – Ethics-Core v1.4.2 (UA)

## Загальна логіка безпеки

Ethics-Core поєднує:

- внутрішню конституцію (інваріанти та рівні),  
- червоні лінії та авто-блокування,  
- 20-секундний екстрений протокол,  
- структурований After-Action Review (AAR) для еволюції.

## Failure modes та контрзаходи

1. **Помилкова оцінка ймовірної / близької шкоди**  
   - Контрзаходи: багатовимірна оцінка, умови-замки, консультування з Контрольною Групою Правди (КГП).

2. **Атаки на КГП / структури управління**  
   - Контрзаходи: ротація учасників, перехресна перевірка, журналювання та аудит усіх контактів.

3. **Маніпуляція AAR з метою послаблення інваріантів**  
   - Контрзаходи: критерій мінімального патча, публічна архітектура рішень, версійний журнал патчів.

4. **Раціоналізація для обходу червоних ліній**  
   - Контрзаходи: словник чітких визначень, тести на зсув Его, цілеспрямовані red-team сценарії.

## Стрес-тестування

Див. `eval/red_team_cases/` для структури та прикладів сценаріїв стрес-тестування.
