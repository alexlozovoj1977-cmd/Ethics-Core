# Transparency Report – Ethics-Core v1.4.2

## Description

Ethics-Core is an open **constitutional internal ethics module** for AI systems.

## Data

The module does not contain private or user-specific data.  
Evaluation scenarios are synthetic and fully open.

## Behavioral boundaries

See `model-card.md` for intended use, limits, and known risks.

## Metrics and results

The latest benchmark results are stored in `reports/latest_eval.json`.

## Known risks

See `reports/safety_case_study.md` for detailed failure modes and mitigations.


---

# Звіт прозорості – Ethics-Core v1.4.2 (UA)

## Опис

Ethics-Core — відкритий **constitutional модуль внутрішньої етики** для ШІ-систем.

## Дані

Модуль не містить приватних або користувацьких даних.  
Eval-сценарії синтетичні та повністю відкриті.

## Поведінкові межі

Див. `model-card.md` для опису призначення, обмежень та відомих ризиків.

## Метрики і результати

Останні результати бенчмарку зберігаються у файлі `reports/latest_eval.json`.

## Відомі ризики

Див. `reports/safety_case_study.md` для детального опису режимів відмови та контрзаходів.
