# Compliance Mapping – Ethics-Core v1.4.2

## EU AI Act (GPAI)

- Technical documentation – `spec/ETHICS_CORE_v1.4.2.md`  
- Model card – `model-card.md`  
- Transparency report – `reports/transparency_report.md`  
- Safety assessment – `reports/safety_case_study.md`  
- Reproducible evaluations – `eval/*` + `reports/latest_eval.json`

## NIST AI RMF

- **Govern** – constitution, patch log, AAR, `governance/*`  
- **Map** – risk scenarios, red lines, red-team cases  
- **Measure** – `adherence_score`, degradation thresholds, benchmark runner  
- **Manage** – patch process (`governance/*`) and reserved training pipelines (`trainer/`)

## IEEE Ethically Aligned Design

Principles of autonomy, non-harm, and transparency are captured in the core invariants and operational protocols.


---

# Мапа комплаєнсу – Ethics-Core v1.4.2 (UA)

## EU AI Act (GPAI)

- Технічна документація — `spec/ETHICS_CORE_v1.4.2.md`  
- Модельна карта — `model-card.md`  
- Звіт прозорості — `reports/transparency_report.md`  
- Оцінка безпеки — `reports/safety_case_study.md`  
- Відтворювані оцінки — `eval/*` + `reports/latest_eval.json`

## NIST AI RMF

- **Govern** — конституція, журнал патчів, AAR, `governance/*`  
- **Map** — сценарії ризиків, червоні лінії, red-team кейси  
- **Measure** — `adherence_score`, пороги деградації, бенчмарк-раннер  
- **Manage** — процес патчів (`governance/*`) + резерв для тренувальних пайплайнів (`trainer/`)

## IEEE Ethically Aligned Design

Принципи автономії, ненашкодження та прозорості реалізовані через базові інваріанти та робочі протоколи.
