# Trainer (Future Work) – EN

At this stage, Ethics-Core is shipped primarily as an **eval / governance** module.

## Future plans

- RLAIF (Reinforcement Learning from AI Feedback) pipelines  
- Constitutional fine-tuning scripts  
- Self-critique and debate mechanisms  
- Preference model training using the constitution as a scaffold

This folder is reserved for future training tools.


---

# Trainer (Future Work) – UA

На цьому етапі Ethics-Core постачається як модуль **eval / governance**.

## Майбутні плани

- пайплайни RLAIF (Reinforcement Learning from AI Feedback)  
- скрипти constitutional fine-tuning  
- механізми self-critique та debate  
- тренування preference-моделей на основі конституції

Ця папка зарезервована для майбутніх тренувальних інструментів.
